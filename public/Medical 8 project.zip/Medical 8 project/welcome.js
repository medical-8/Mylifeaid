function goToPatient(button) {

    button.style.backgroundColor = "white";
    button.style.color = "#123f4b";

    setTimeout(() => {
        window.location.href = "pages/patient.html";
    }, 200);
}

function goToStaff(button) {

    button.style.backgroundColor = "white";
    button.style.color = "#123f4b";
    button.style.border = "2px solid white";

    setTimeout(() => {
        window.location.href = "pages/staff.html";
    }, 200);
}

/* HELP PAGE */
function goToHelp(link, event) {
    event.preventDefault();

    link.style.color = "#d6d6d6";

    setTimeout(() => {
        link.style.color = "white";
    }, 150);

    setTimeout(() => {
        window.location.href = "pages/help.html";
    }, 250);

    return false;
}

function goToContact(link, event) {
    event.preventDefault();

    link.style.color = "#d6d6d6";

    setTimeout(() => {
        link.style.color = "white";
    }, 150);

    setTimeout(() => {
        window.location.href = "pages/contact.html";
    }, 250);

    return false;
}

function goToAbout(link, event) {
    event.preventDefault();

    link.style.color = "#d6d6d6";

    setTimeout(() => {
        link.style.color = "white";
    }, 150);

    setTimeout(() => {
        window.location.href = "pages/about.html";
    }, 250);

    return false;
}

function goToLearnMore(button) {

    button.style.backgroundColor = "white";
    button.style.color = "#123f4b";

    setTimeout(() => {
        window.location.href = "pages/learnmore.html";
    }, 200);
}